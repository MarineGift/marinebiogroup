// Placeholder component
export default function ProductCard() {
  return <div>Product Card Component</div>;
}