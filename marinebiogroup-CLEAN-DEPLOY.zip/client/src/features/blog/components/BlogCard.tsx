// Placeholder component
export default function BlogCard() {
  return <div>Blog Card Component</div>;
}