// Placeholder component
export default function GalleryFilter() {
  return <div>Gallery Filter Component</div>;
}