// Placeholder component
export default function GalleryModal() {
  return <div>Gallery Modal Component</div>;
}