// Placeholder component
export default function ContactForm() {
  return <div>Contact Form Component</div>;
}