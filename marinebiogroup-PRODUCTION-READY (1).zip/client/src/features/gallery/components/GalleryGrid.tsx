// Placeholder component
export default function GalleryGrid() {
  return <div>Gallery Grid Component</div>;
}