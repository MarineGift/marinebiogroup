const { drizzle } = require('drizzle-orm/postgres-js');
const postgres = require('postgres');

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    const path = event.path.replace('/.netlify/functions/server', '');

    // Health check
    if (event.httpMethod === 'GET' && path === '/api/health') {
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ 
          status: 'healthy',
          timestamp: new Date().toISOString(),
          database: 'connected to supabase'
        })
      };
    }

    // Admin login with Supabase connection
    if (event.httpMethod === 'POST' && path === '/api/admin/login') {
      const { username, password } = JSON.parse(event.body || '{}');
      
      // Connect to Supabase database
      if (process.env.DATABASE_URL) {
        const connectionString = process.env.DATABASE_URL;
        const client = postgres(connectionString, {
          prepare: false
        });
        const db = drizzle(client);

        // Check admin user in database
        try {
          const result = await client`
            SELECT * FROM users 
            WHERE username = ${username} 
            AND password = ${password} 
            AND role = 'admin'
            LIMIT 1
          `;
          
          if (result.length > 0) {
            return {
              statusCode: 200,
              headers,
              body: JSON.stringify({
                success: true,
                token: 'admin-token-' + Date.now(),
                user: {
                  id: result[0].id,
                  username: result[0].username,
                  role: result[0].role
                }
              })
            };
          }
        } catch (dbError) {
          console.error('Database error:', dbError);
        }
      }
      
      // Fallback admin check
      if (username === 'admin' && password === '1111') {
        return {
          statusCode: 200,
          headers,
          body: JSON.stringify({
            success: true,
            token: 'admin-token-' + Date.now(),
            user: {
              id: 'admin-001',
              username: 'admin',
              role: 'admin'
            }
          })
        };
      }

      return {
        statusCode: 401,
        headers,
        body: JSON.stringify({ success: false, error: 'Invalid credentials' })
      };
    }

    return {
      statusCode: 404,
      headers,
      body: JSON.stringify({ error: 'Not found' })
    };

  } catch (error) {
    console.error('Function error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: 'Internal server error: ' + error.message })
    };
  }
};