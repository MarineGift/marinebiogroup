import serverless from 'serverless-http';
import express from 'express';

const app = express();
app.use(express.json());

// Health check
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'healthy',
    timestamp: new Date().toISOString()
  });
});

// Admin login - ULTRA SIMPLE
app.post('/api/admin/login', (req, res) => {
  const { username, password } = req.body;
  
  if (username === 'admin' && password === '1111') {
    res.json({
      success: true,
      token: 'admin-token-' + Date.now(),
      user: { id: 'admin', username: 'admin', role: 'admin' }
    });
  } else {
    res.status(401).json({ success: false, error: 'Invalid credentials' });
  }
});

export const handler = serverless(app);