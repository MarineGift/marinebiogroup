// Placeholder component
export default function BlogGrid() {
  return <div>Blog Grid Component</div>;
}