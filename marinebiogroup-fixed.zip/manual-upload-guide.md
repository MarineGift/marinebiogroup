# 🔧 수동 업로드 가이드 - 100개 파일 제한 우회

## 현재 상황
- ZIP 업로드 완료했으나 자동 압축 해제 실패
- GitHub Actions가 ZIP을 인식하지 못함
- 수동으로 폴더별 업로드 필요

## 📋 단계별 업로드 전략

### 1단계: 핵심 설정 파일들 (약 20개)
GitHub에서 직접 업로드할 파일들:
```
✅ package.json
✅ package-lock.json  
✅ netlify.toml
✅ vite.config.ts
✅ tailwind.config.ts
✅ tsconfig.json
✅ drizzle.config.ts
✅ components.json
✅ postcss.config.js
✅ .gitignore
✅ README.md
✅ vercel.json
```

### 2단계: 백엔드 폴더들 (약 15개)
```
✅ server/ 폴더 전체 (5개 파일)
✅ shared/ 폴더 전체 (3개 파일)
✅ netlify/ 폴더 전체 (1개 파일)
✅ .github/ 폴더 전체 (2개 파일)
```

### 3단계: 프론트엔드 - 분할 업로드 필요
client/ 폴더는 118개 파일이므로 나누어 업로드:

**3-1. client/src/pages/ 폴더만** (약 10개)
**3-2. client/src/components/ui/ 폴더의 일부** (50개씩)
**3-3. client/src/components/ui/ 폴더의 나머지**
**3-4. client/src/features/ 폴더들**
**3-5. 나머지 client/ 파일들**

## 🚀 즉시 실행할 방법

### 방법 A: 로컬 Git 사용 (가장 확실)
1. 컴퓨터에 Git 설치
2. ZIP 파일 압축 해제
3. Git으로 푸시

### 방법 B: GitHub CLI 사용
1. GitHub CLI 설치
2. 명령어로 일괄 업로드

### 방법 C: 폴더별 수동 업로드 (확실함)
단계별로 차근차근 업로드

## ⏰ 시간 절약 팁
- 가장 중요한 파일들부터 업로드
- 설정 파일들이 우선순위 1번
- client/ 폴더는 마지막에