#!/bin/bash

echo "=== Netlify 배포 문제 해결 스크립트 ==="
echo ""

echo "🔍 현재 상황 분석:"
echo "- marinebiogroup.com이 GitHub Pages로 연결됨"
echo "- README.md 파일만 표시되고 있음"
echo "- React 애플리케이션이 로드되지 않음"
echo ""

echo "🚀 해결 단계:"
echo ""

echo "1. Netlify 대시보드 확인"
echo "   - https://app.netlify.com 접속"
echo "   - marinebiogroup 사이트 상태 확인"
echo "   - 빌드 로그에서 오류 확인"
echo ""

echo "2. GitHub Pages 비활성화"
echo "   - GitHub 저장소 → Settings → Pages"
echo "   - Source를 'None'으로 변경"
echo ""

echo "3. Netlify 도메인 설정"
echo "   - Site settings → Domain management"
echo "   - Custom domain 추가/수정"
echo "   - DNS 설정 확인"
echo ""

echo "4. 빌드 설정 확인"
echo "   - Build command: npm run build"
echo "   - Publish directory: dist/public"
echo "   - Node version: 18"
echo ""

echo "💡 임시 해결책:"
echo "Netlify에서 제공하는 기본 URL로 먼저 접속 테스트"
echo "(예: xxx.netlify.app)"