#!/bin/bash

echo "=== MarineBioGroup 파일 업로드 스크립트 ==="
echo ""

echo "📁 ZIP 파일 상태 확인:"
if [ -f "marinebiogroup-source.zip" ]; then
    echo "✅ ZIP 파일 존재: marinebiogroup-source.zip"
    ls -lh marinebiogroup-source.zip
else
    echo "❌ ZIP 파일 없음 - 새로 생성 필요"
fi

echo ""
echo "🚀 추천 업로드 방법:"
echo ""

echo "방법 1: GitHub Desktop (가장 간단)"
echo "1. GitHub Desktop 설치: https://desktop.github.com"  
echo "2. 저장소 클론"
echo "3. ZIP 파일 압축 해제 후 폴더에 복사"
echo "4. 커밋 & 푸시"
echo ""

echo "방법 2: Git 명령어 (고급 사용자)"
echo "1. 로컬에 저장소 클론"
echo "2. git clone https://github.com/[USERNAME]/marinebiogroup-website.git"
echo "3. 파일 복사 후 git add ."
echo "4. git commit -m 'Add all files'"
echo "5. git push"
echo ""

echo "방법 3: VS Code (개발자 친화적)"
echo "1. VS Code 설치"
echo "2. Git 확장으로 저장소 클론"
echo "3. 파일 복사 후 Source Control에서 커밋"
echo ""

echo "💡 가장 빠른 방법: GitHub Desktop 사용!"
echo "   설치 시간: 2분, 업로드 시간: 3분 = 총 5분 완료"