#!/bin/bash

echo "=== ZIP 파일 생성 시작 ==="

# 필요없는 폴더 제외하고 ZIP 생성
zip -r marinebiogroup-source.zip . \
  -x "node_modules/*" \
  -x ".git/*" \
  -x "dist/*" \
  -x ".cache/*" \
  -x ".local/*" \
  -x ".upm/*" \
  -x "*.zip"

echo "ZIP 파일 생성 완료: marinebiogroup-source.zip"
echo "파일 크기:"
ls -lh marinebiogroup-source.zip

echo ""
echo "=== 업로드 방법 ==="
echo "1. 생성된 ZIP 파일을 다운로드"
echo "2. GitHub 저장소에서 'Add file' > 'Upload files'"
echo "3. ZIP 파일을 드래그 앤 드롭"
echo "4. 커밋 메시지: 'Initial project upload'"
echo "5. 'Commit changes' 클릭"