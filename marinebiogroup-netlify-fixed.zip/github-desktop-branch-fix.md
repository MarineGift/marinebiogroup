# 🎯 GitHub Desktop 브랜치 문제 해결

## 현재 상황
- 브랜치: marinebiogroup (main 아님)
- Untracked files: .github/ 폴더
- 커밋 실패 상태

## 즉시 해결 방법

### 1단계: 모든 파일 선택
GitHub Desktop에서:
1. "Changes" 탭 확인
2. **모든 파일 체크박스 선택** (특히 .github/ 폴더)
3. 모든 untracked files 포함

### 2단계: 강제 커밋
1. Summary: `Add all project files and fix deployment`
2. Description: `Include GitHub workflows and deployment configuration`
3. **"Commit to marinebiogroup"** 클릭

### 3단계: 푸시 실행
1. 커밋 후 **"Push origin"** 버튼 클릭
2. marinebiogroup 브랜치로 푸시

## 중요: 브랜치 설정
- 기본 브랜치가 marinebiogroup이므로 정상
- Netlify도 marinebiogroup 브랜치를 모니터링해야 함

## Netlify 브랜치 설정 변경
1. Netlify 대시보드 → Site settings
2. Build & deploy → Continuous Deployment
3. Branch를 "marinebiogroup"로 변경