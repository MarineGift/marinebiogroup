#!/bin/bash

# GitHub 대용량 파일 업로드 스크립트
# 100개 파일 제한 우회 방법

echo "=== GitHub 대용량 파일 업로드 솔루션 ==="
echo ""

echo "방법 1: ZIP 파일로 압축 후 업로드"
echo "1. 전체 프로젝트를 ZIP으로 압축"
echo "2. GitHub에서 ZIP 파일 업로드"
echo "3. GitHub Actions에서 자동 압축 해제"
echo ""

echo "방법 2: 폴더별 분할 업로드"
echo "1. client/ 폴더만 별도 업로드"
echo "2. .github/ 폴더만 별도 업로드"
echo "3. 나머지 파일들 업로드"
echo ""

echo "방법 3: Git CLI 사용 (추천)"
echo "1. 로컬 컴퓨터에 Git 설치"
echo "2. Replit에서 ZIP 다운로드"
echo "3. 로컬에서 Git 푸시"
echo ""

echo "현재 파일 개수 확인..."
find . -type f \( ! -path "./node_modules/*" ! -path "./.git/*" ! -path "./dist/*" ! -path "./.cache/*" ! -path "./.local/*" ! -path "./.upm/*" \) | wc -l