# 🔧 Netlify Build 설정 구성

## 현재 문제
- Build command: Not set
- Publish directory: Not set 
- 빌드 설정이 완전히 비어있음

## 즉시 설정할 값들

### "Configure" 버튼 클릭 후 입력:

**Build command:**
```
npm run build
```

**Publish directory:**
```
dist/public
```

**Base directory:**
```
/
```

**Functions directory:**
```
netlify/functions
```

**Environment variables (추가 필요):**
```
NODE_VERSION = 18
NPM_FLAGS = --production=false
```

## 설정 후 액션
1. "Save" 클릭
2. "Deploy site" 버튼이 나타날 것임
3. 수동 배포 실행